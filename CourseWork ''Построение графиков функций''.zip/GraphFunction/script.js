// Инициализация графика
const ctx = document.getElementById('myChart').getContext('2d');
let chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'График функции',
            data: [],
            borderColor: 'blue',
            borderWidth: 1,
            fill: false
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                type: 'linear',
                position: 'bottom',
                min: -10,
                max: 10,
                grid: {
                    color: function(context) {
                        return context.tick.value === 0 ? 'black' : 'rgba(0, 0, 0, 0.1)';
                    },
                    lineWidth: function(context) {
                        return context.tick.value === 0 ? 2 : 1;
                    }
                },
                ticks: {
                    stepSize: 1,
                    callback: function (value) {
                        return value;
                    }
                }
            },
            y: {
                type: 'linear',
                min: -10,
                max: 10,
                grid: {
                    color: function(context) {
                        return context.tick.value === 0 ? 'black' : 'rgba(0, 0, 0, 0.1)';
                    },
                    lineWidth: function(context) {
                        return context.tick.value === 0 ? 2 : 1;
                    }
                },
                ticks: {
                    stepSize: 1,
                    callback: function (value) {
                        return value;
                    }
                }
            }
        },
        plugins: {
            legend: {
                display: true,
            },
            tooltip: {
                enabled: true,
                mode: 'nearest',
                intersect: false,
                callbacks: {
                    label: function(context) {
                        const x = context.parsed.x;
                        const y = context.parsed.y;
                        return `x = ${x.toFixed(4)}; y = ${y.toFixed(4)}`;
                    }
                }
            }
        }
    }
});

// Добавление поддержки новых функций
math.import({
    logbase: function(a, x) {
        return math.log(x) / math.log(a);
    },
    powbase: function(a, x) {
        return math.pow(a, x);
    },
    root: function(n, x) {
         return x < 0 && n % 2 !== 0 ? -Math.pow(-x, 1 / n) : Math.pow(x, 1 / n);
    },
    sqrt: function(x) {
        return math.sqrt(x); // Явно добавляем поддержку sqrt(x)
    }
});

// Функция для обновления шага сетки и подписей на осях
function updateScale(scale) {
    chart.options.scales.x.ticks.stepSize = scale;
    chart.options.scales.x.ticks.callback = function (value) {
        return parseFloat((value).toFixed(4));
    };

    chart.options.scales.y.ticks.stepSize = scale;
    chart.options.scales.y.ticks.callback = function (value) {
        return parseFloat((value).toFixed(4));
    };

    chart.options.scales.x.min = -10 * scale;
    chart.options.scales.x.max = 10 * scale;
    chart.options.scales.y.min = -10 * scale;
    chart.options.scales.y.max = 10 * scale;

    chart.update();
}

// Функция для построения графика
function plotFunction() {
    const functionInput = document.getElementById('functionInput').value;
    const scale = parseFloat(document.getElementById('scaleInput').value);

    updateScale(scale);

    chart.data.labels = [];
    chart.data.datasets[0].data = [];

    for (let x = -10; x <= 10; x += 0.1) {
        const scaledX = x * scale;

        try {
            // Проверка области определения функций
            if (functionInput.includes('log') && scaledX <= 0) continue; // Логарифм определён только для x > 0
            if ((functionInput.includes('sqrt') || functionInput.includes('root(2,')) && scaledX < 0) continue; // Квадратный корень определён только для x >= 0
            if (functionInput.includes('root(')) {
                const n = parseFloat(functionInput.split(',')[0].split('(')[1]); // Получение степени корня
                if (n % 2 === 0 && scaledX < 0) continue; // Для чётных корней x >= 0
            }
            if ((functionInput.includes('asin') || functionInput.includes('acos')) && (scaledX < -1 || scaledX > 1)) continue; // Обратные тригонометрические функции определены для x ∈ [-1, 1]

            const scope = { x: scaledX };
            const y = math.evaluate(functionInput, scope);
            chart.data.labels.push(scaledX);
            chart.data.datasets[0].data.push(y);
        } catch (error) {
            console.error("Ошибка ввода функции:", error);
            alert("Ошибка ввода функции. Проверьте корректность ввода.");
            return;
        }
    }

    chart.update();
}