document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // предотвращение стандартного поведение формы
    var email = document.getElementById('email').value;
    var login = document.getElementById('login').value;
    var password = document.getElementById('password').value;
    var repeatPassword = document.getElementById('repeatPassword').value;
    if (password !== repeatPassword) {
        alert("Passwords do not match!");
        return;
    }
    var confirmationMessage = document.getElementById('confirmationMessage');
    confirmationMessage.textContent = `На почту ${email} отправлено письмо с подтверждением.`;
});